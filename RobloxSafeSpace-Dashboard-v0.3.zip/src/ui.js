(function (root) {
  'use strict';
  const paths = {
    grid: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
    bell: 'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9 M10 21h4',
    route: 'M5 5a2 2 0 1 0 0 .1 M19 19a2 2 0 1 0 0 .1 M7 5h9a4 4 0 0 1 0 8H8a3 3 0 0 0 0 6h9',
    code: 'M8 8l-4 4 4 4 M16 8l4 4-4 4 M14 4l-4 16',
    people:
      'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M17 3a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87',
    settings: 'M4 7h16 M4 17h16 M8 4v6 M16 14v6',
    shield: 'M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6z M8 12l3 3 5-6',
    logs: 'M8 3h10l3 3v15H3V3h2 M8 8h9 M8 12h9 M8 16h6',
    logout: 'M9 3H4v18h5 M14 8l5 4-5 4 M8 12h12',
    sun: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1 1 M18 18l1 1 M5 19l1-1 M18 6l1-1',
    moon: 'M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8',
    search: 'M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14 M15 15l6 6',
    plus: 'M12 5v14 M5 12h14',
    arrow: 'M5 12h14 M14 7l5 5-5 5',
    refresh: 'M20 7v5h-5 M4 17v-5h5 M6 6a8 8 0 0 1 13 2 M18 18a8 8 0 0 1-13-2',
    down: 'M6 9l6 6 6-6',
    edit: 'M4 17l-1 4 4-1L20 7l-3-3z M14 7l3 3',
    trash: 'M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7',
    close: 'M6 6l12 12 M18 6L6 18',
    check: 'M5 12l4 4L19 6',
    eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12 M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',
    lock: 'M6 10h12v11H6z M8 10V6a4 4 0 0 1 8 0v4',
    clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 7v5l3 2',
    menu: 'M4 6h16 M4 12h16 M4 18h16',
    file: 'M6 3h9l4 4v14H6z M14 3v5h5 M9 12h7 M9 16h5',
    download: 'M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5',
    info: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 11v6 M12 7v.1',
    chat: 'M21 11a9 8 0 0 1-9 8H5l-3 3V11a9 8 0 0 1 19 0 M7 10h10 M7 14h6',
    activity: 'M2 12h5l3-8 4 16 3-8h5',
    back: 'M19 12H5 M10 7l-5 5 5 5',
    flask: 'M9 3h6 M10 3v7l-6 9a1 1 0 0 0 1 2h14a1 1 0 0 0 1-2l-6-9V3 M7 16h10',
  };
  const escape = (s) =>
    String(s ?? '').replace(
      /[&<>"']/g,
      (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
    );
  const icon = (name) =>
    /* HTML */ `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">
      <path d="${paths[name] || paths.grid}" />
    </svg>`;
  const date = (value, full = false) =>
    value
      ? new Intl.DateTimeFormat('th-TH', {
          day: '2-digit',
          month: 'short',
          ...(full
            ? { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Bangkok' }
            : { timeZone: 'Asia/Bangkok' }),
        }).format(new Date(value))
      : 'ยังไม่เข้าใช้งาน';
  const badge = (label, color = 'green') =>
    /* HTML */ `<span class="badge ${color}">${escape(label)}</span>`;
  const status = (s) =>
    badge(
      {
        open: 'ยังไม่รับทราบ',
        handled: 'รับทราบแล้ว',
        live: 'Active',
        disabled: 'Disabled',
        expired: 'Expired',
        draft: 'Draft',
        review: 'In review',
        complete: 'Complete',
        in_progress: 'In progress',
      }[s] || s,
      {
        open: 'amber',
        handled: 'green',
        live: 'green',
        disabled: '',
        expired: 'red',
        draft: '',
        review: 'blue',
      }[s] || 'blue',
    );
  const btn = (
    label,
    action,
    { id = '', kind = '', icon: ico = '', extra = '', disabled = false } = {},
  ) =>
    /* HTML */ `<button
      type="button"
      class="btn ${kind}"
      data-action="${action}"
      ${id ? `data-id="${escape(id)}"` : ''}
      ${extra}
      ${disabled ? 'disabled' : ''}
    >
      ${ico ? icon(ico) : ''}${escape(label)}
    </button>`;
  const input = (label, name, value = '', type = 'text', extra = '') =>
    /* HTML */ `<label class="field"
      >${escape(label)}<input name="${name}" type="${type}" value="${escape(value)}" ${extra}
    /></label>`;
  const textarea = (label, name, value = '', extra = '') =>
    /* HTML */ `<label class="field"
      >${escape(label)}<textarea name="${name}" ${extra}>${escape(value)}</textarea>
    </label>`;
  const select = (label, name, options, value, extra = '') =>
    /* HTML */ `<label class="field"
      >${escape(label)}<select name="${name}" ${extra}>
        ${options.map((o) => /* HTML */ `<option value="${escape(o.value)}" ${String(o.value) === String(value) ? 'selected' : ''}>${escape(o.label)}</option>`).join('')}
      </select></label
    >`;
  const empty = (title, text, action = '') =>
    /* HTML */ `<div class="empty-state">
      <div class="empty-icon">${icon('file')}</div>
      <h2>${escape(title)}</h2>
      <p>${escape(text)}</p>
      ${action}
    </div>`;
  const table = (headers, rows) =>
    /* HTML */ `<div class="table-scroll">
      <table class="data-table">
        <thead>
          <tr>
            ${headers.map((h) => /* HTML */ `<th scope="col">${h}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${rows
            .map(
              (row) =>
                /* HTML */ `<tr>
                  ${row.map((c) => /* HTML */ `<td>${c}</td>`).join('')}
                </tr>`,
            )
            .join('')}
        </tbody>
      </table>
    </div>`;
  const csrfSafeCsv = (rows) =>
    rows
      .map((r) =>
        r
          .map((v) => {
            const s = String(v ?? '');
            return '"' + (/^[=+@\-\t\r]/.test(s) ? "'" : '') + s.replace(/"/g, '""') + '"';
          })
          .join(','),
      )
      .join('\r\n');
  let toastTimer;
  function toast(message) {
    const el = document.getElementById('toast');
    clearTimeout(toastTimer);
    el.textContent = message;
    el.hidden = false;
    toastTimer = setTimeout(() => (el.hidden = true), 5000);
  }
  let restoreFocus;
  function closeModal(force = false) {
    const d = document.getElementById('modal');
    if (d.dataset.busy === 'true' && !force) return;
    d.close();
    d.innerHTML = '';
    delete d.dataset.busy;
    if (restoreFocus?.isConnected) restoreFocus.focus({ preventScroll: true });
    else {
      const heading = document.querySelector('#main h1, #main h2');
      if (heading) {
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
      }
    }
  }
  function modal({ title, body, submit = 'บันทึก', onSubmit, wide = false, danger = false }) {
    const d = document.getElementById('modal');
    if (d.open) closeModal(true);
    restoreFocus = document.activeElement;
    d.className = wide ? 'wide' : '';
    d.innerHTML = /* HTML */ `<form id="modal-form">
      <div class="modal-head">
        <h2 id="modal-title">${escape(title)}</h2>
        <button class="btn icon-btn ghost" type="button" data-modal-close aria-label="ปิดหน้าต่าง">
          ${icon('close')}
        </button>
      </div>
      <div class="modal-body">
        ${body}
        <div id="modal-error" class="form-error" role="alert" hidden></div>
      </div>
      <div class="modal-actions">
        <button class="btn" type="button" data-modal-close>ยกเลิก</button
        >${onSubmit ? /* HTML */ `<button class="btn ${danger ? 'danger' : 'primary'}" type="submit">${escape(submit)}</button>` : ''}
      </div>
    </form>`;
    // Require both pointer-down and click on the backdrop, so dragging a
    // selection out of the dialog does not accidentally dismiss it.
    let startedOutside = false;
    const outside = (event) => {
      const rect = d.getBoundingClientRect();
      return (
        event.target === d &&
        (event.clientX < rect.left ||
          event.clientX > rect.right ||
          event.clientY < rect.top ||
          event.clientY > rect.bottom)
      );
    };
    d.onpointerdown = (event) => {
      startedOutside = outside(event);
    };
    d.onpointercancel = () => {
      startedOutside = false;
    };
    d.onclick = (event) => {
      if (startedOutside && outside(event)) closeModal();
      startedOutside = false;
    };
    d.querySelectorAll('[data-modal-close]').forEach((b) => (b.onclick = () => closeModal()));
    d.oncancel = (e) => {
      e.preventDefault();
      closeModal();
    };
    d.querySelector('form').onsubmit = async (e) => {
      e.preventDefault();
      if (!onSubmit || d.dataset.busy === 'true') return;
      const form = e.currentTarget;
      const formData = new FormData(form);
      d.dataset.busy = 'true';
      d.querySelectorAll('button').forEach((b) => (b.disabled = true));
      const err = d.querySelector('#modal-error');
      err.hidden = true;
      try {
        await onSubmit(formData);
        closeModal(true);
      } catch (ex) {
        if (!d.open) return;
        err.textContent = ex.message || 'ไม่สามารถดำเนินการได้';
        err.hidden = false;
        err.setAttribute('tabindex', '-1');
        err.focus();
        delete d.dataset.busy;
        d.querySelectorAll('button').forEach((b) => (b.disabled = false));
      }
    };
    d.showModal();
  }
  const confirm = (title, text, onConfirm, { danger = false, label = 'ยืนยัน', body = '' } = {}) =>
    modal({
      title,
      body: /* HTML */ `<div class="confirm-icon">${icon(danger ? 'trash' : 'info')}</div>
        <p class="confirm-text">${escape(text)}</p>
        ${body}
        <p class="modal-help">
          โหมดจำลอง: เปลี่ยนเฉพาะข้อมูลในหน่วยความจำของหน้านี้ ไม่กระทบ Backend หรือผู้เล่นจริง
        </p>`,
      submit: label,
      onSubmit: onConfirm,
      danger,
    });
  const exports = {
    escape,
    icon,
    date,
    badge,
    status,
    btn,
    input,
    textarea,
    select,
    empty,
    table,
    toast,
    modal,
    closeModal,
    confirm,
    csv: csrfSafeCsv,
  };
  root.SafeSpaceUI = exports;
  if (typeof module !== 'undefined') module.exports = exports;
})(typeof globalThis !== 'undefined' ? globalThis : window);
