/* Form-card editor. Keeps the existing mock view-model; no new API schema. */
window.SafeSpaceJourneyEditor = function (ctx) {
  'use strict';
  const { state, writable, pageHead, draw } = ctx;
  const U = SafeSpaceUI;
  const { escape: E, btn: B, input: field, textarea, select } = U;
  const $ = (selector) => document.querySelector(selector);

  function dirty() {
    state.dirty = true;
    const note = $('.page-head p');
    if (note) note.textContent = 'มีการแก้ไขที่ยังไม่บันทึก · ร่างจำลอง';
    const saveState = $('#editor-save-state');
    if (saveState) saveState.textContent = 'ยังไม่ได้บันทึกการแก้ไข';
  }

  function focusSection(section) {
    const target = $(`#journey-${section}`);
    if (!target) return;
    target.scrollIntoView({ behavior: 'instant', block: 'start' });
    target.querySelector('h2, h3')?.focus({ preventScroll: true });
  }

  function render() {
    const j = state.editor;
    const step = j.steps[state.step];
    const readOnly = !writable('journeys');
    const off = readOnly ? 'disabled' : '';
    const quiz = step?.quiz;
    const choiceRows = quiz
      ? quiz.choices
          .map(
            (choice, index) =>
              /* HTML */ ` <div class="choice-row">
                ${
                  quiz.mode === 'graded'
                    ? /* HTML */ `<input
                        type="radio"
                        name="correct-answer"
                        data-choice-answer="${index}"
                        aria-label="ตัวเลือก ${index + 1} เป็นคำตอบที่ถูกต้อง"
                        ${quiz.answer === index ? 'checked' : ''}
                        ${off}
                      />`
                    : '<span class="choice-dot" aria-hidden="true"></span>'
                }
                <label class="sr-only" for="choice-${index}">ตัวเลือก ${index + 1}</label>
                <input
                  id="choice-${index}"
                  data-choice="${index}"
                  value="${E(choice)}"
                  maxlength="300"
                  placeholder="ตัวเลือก ${index + 1}"
                  ${off}
                />
                ${!readOnly ? B('ลบ', 'remove-choice', { kind: 'ghost small', extra: `data-index="${index}" aria-label="ลบตัวเลือก ${index + 1}"`, disabled: quiz.choices.length <= 2 }) : ''}
              </div>`,
          )
          .join('')
      : '';

    return (
      pageHead(
        j.id ? 'Journey editor' : 'สร้าง Journey',
        readOnly
          ? 'ดูเนื้อหากิจกรรม · โหมดอ่านอย่างเดียว'
          : `${state.dirty ? 'มีการแก้ไขที่ยังไม่บันทึก' : 'เรียงเนื้อหาทีละขั้น เหมือนสร้างแบบฟอร์ม'} · ร่างจำลอง`,
        B('กลับรายการ', 'exit-editor', { icon: 'back' }),
        'CONTENT STUDIO / EDITOR',
      ) +
      /* HTML */ ` <div class="journey-form">
        <nav class="form-section-nav" aria-label="ไปยังส่วนของแบบฟอร์ม">
          ${[
            ['details', '1', 'ข้อมูลกิจกรรม'],
            ['dialog', '2', 'บทสนทนา'],
            ['quiz', '3', 'คำถาม'],
          ]
            .map(
              ([id, n, label]) =>
                /* HTML */ `<button type="button" data-action="editor-tab" data-tab="${id}">
                  <span>${n}</span>${label}
                </button>`,
            )
            .join('')}
        </nav>
        <section class="card form-card form-intro" id="journey-details">
          <div class="form-card-heading">
            <span class="form-eyebrow">เริ่มต้นที่นี่</span>
            <h2 tabindex="-1">กิจกรรมนี้เกี่ยวกับอะไร?</h2>
            <p>ตั้งชื่อและอธิบายสั้น ๆ เพื่อให้ทีมเข้าใจตรงกัน</p>
          </div>
          ${field('ชื่อ Journey', 'title', j.title, 'text', `data-edit="title" maxlength="120" placeholder="เช่น พื้นที่ของเรา" ${off}`)}
          ${textarea('คำอธิบายกิจกรรม', 'description', j.description, `data-edit="description" maxlength="1000" rows="3" placeholder="ผู้เล่นจะได้ทำอะไรในกิจกรรมนี้" ${off}`)}
          ${select(
            'สถานะเนื้อหา',
            'status',
            [
              { value: 'draft', label: 'Draft · กำลังร่าง' },
              { value: 'review', label: 'In review · รอตรวจเนื้อหา' },
            ],
            j.status,
            `data-edit="status" ${off}`,
          )}
          <p class="field-hint">สถานะจำลองสำหรับรีวิวเนื้อหา · ยังไม่มีการเผยแพร่เข้าเกม</p>
        </section>

        <section class="step-selector card" aria-label="ขั้นตอนของกิจกรรม">
          <div class="row between">
            <div>
              <span class="form-eyebrow">ลำดับการเล่น</span>
              <h2>ขั้นตอน ${state.step + 1} จาก ${j.steps.length}</h2>
            </div>
            ${!readOnly ? B('เพิ่มขั้นตอน', 'add-step', { icon: 'plus', kind: 'small', disabled: j.steps.length >= 30 }) : ''}
          </div>
          <div class="step-pills">
            ${j.steps.map((s, i) => /* HTML */ `<button type="button" data-action="select-step" data-index="${i}" aria-pressed="${i === state.step}"><span>${i + 1}</span>${E(s.name || 'ขั้นตอนใหม่')}</button>`).join('')}
          </div>
          <p class="field-hint">เลือกขั้นตอนเพื่อแก้บทสนทนาและคำถามด้านล่าง ข้อมูลร่างจะอยู่ครบเมื่อสลับขั้นตอน</p>
        </section>

        ${
          step
            ? /* HTML */ `<section class="card form-card step-form" id="journey-dialog">
                  <div class="form-card-heading">
                    <span class="form-eyebrow">STEP ${state.step + 1} / บทสนทนา</span>
                    <h2 tabindex="-1">ให้ผู้เล่นพบกับใคร?</h2>
                    <p>กำหนดตัวละครและสิ่งที่อยากสื่อสารในขั้นตอนนี้</p>
                  </div>
                  <div class="form-grid">
                    ${field('ชื่อขั้นตอน', 'stepName', step.name, 'text', `data-step-edit="name" maxlength="120" ${off}`)}${field('รหัสตัวละคร (NPC ID)', 'npc', step.npc, 'text', `data-step-edit="npc" maxlength="60" placeholder="เช่น guide_01" ${off}`)}
                  </div>
                  <p class="field-hint">NPC ID ต้องตรงกับตัวละครที่ทีมเกมกำหนด</p>
                  ${textarea('ตัวละครจะพูดว่าอะไร?', 'dialog', step.dialog, `data-step-edit="dialog" rows="5" maxlength="3000" placeholder="เขียนบทสนทนาที่ผู้เล่นจะเห็น…" ${off}`)}
                  ${
                    !readOnly
                      ? /* HTML */ `<div class="step-footer">
                          <span class="small muted">จัดลำดับขั้นตอนนี้</span>
                          <div class="row">
                            ${B('เลื่อนขึ้น', 'move-step', { extra: 'data-direction="-1"', kind: 'small', disabled: state.step === 0 })}${B('เลื่อนลง', 'move-step', { extra: 'data-direction="1"', kind: 'small', disabled: state.step === j.steps.length - 1 })}${B('ลบขั้นตอน', 'remove-step', { kind: 'danger small', disabled: j.steps.length === 1 })}
                          </div>
                        </div>`
                      : ''
                  }
                </section>

                <section class="card form-card question-form" id="journey-quiz">
                  <div class="form-card-heading">
                    <span class="form-eyebrow">STEP ${state.step + 1} / คำถาม</span>
                    <h2 tabindex="-1">ชวนผู้เล่นตอบคำถาม</h2>
                    <p>เพิ่มคำถามหลังบทสนทนา หรือใช้เฉพาะบทสนทนาก็ได้</p>
                  </div>
                  <label class="check quiz-toggle"
                    ><input id="has-quiz" type="checkbox" ${quiz ? 'checked' : ''} ${off} /><span
                      >มีคำถามในขั้นตอนนี้</span
                    ></label
                  >
                  ${
                    quiz
                      ? `
            ${field('คำถาม', 'quizTitle', quiz.title, 'text', `data-quiz-edit="title" maxlength="300" placeholder="พิมพ์คำถามของคุณ…" ${off}`)}
            ${select(
              'รูปแบบคำถาม',
              'quizMode',
              [
                { value: 'survey', label: 'สำรวจความคิดเห็น · ไม่มีถูกหรือผิด' },
                { value: 'graded', label: 'แบบทดสอบ · เลือกคำตอบที่ถูกต้อง' },
              ],
              quiz.mode,
              `data-quiz-edit="mode" ${off}`,
            )}
            <fieldset class="choice-list"><legend>ตัวเลือกคำตอบ <span class="small muted">2–8 ตัวเลือก</span></legend>${choiceRows}</fieldset>
            <div class="row between">${!readOnly ? B('เพิ่มตัวเลือก', 'add-choice', { icon: 'plus', kind: 'ghost small', disabled: quiz.choices.length >= 8 }) : ''}<span class="field-hint">${quiz.mode === 'graded' ? 'เลือกวงกลมหน้าคำตอบที่ถูกต้อง' : 'ทุกคำตอบเป็นความคิดเห็นของผู้เล่น'}</span></div>
          `
                      : '<div class="quiz-empty">ขั้นตอนนี้ใช้เฉพาะบทสนทนา เปิดตัวเลือกด้านบนเมื่อต้องการเพิ่มคำถาม</div>'
                  }
                  <p class="field-hint">
                    ต้นแบบรองรับ 1 คำถามต่อขั้นตามข้อมูลจำลองเดิม · ผล Quiz ไม่ใช้สรุปสุขภาพจิต
                  </p>
                </section>`
            : ''
        }

        <details class="card advanced-settings">
          <summary>การตั้งค่าเพิ่มเติม <span>ข้อความของระบบ · ผลรวม · Export</span></summary>
          <div class="advanced-body">
            ${field('ข้อความเมื่อคุย NPC ผิดลำดับ', 'outOfOrder', j.outOfOrder, 'text', `data-edit="outOfOrder" ${off}`)}
            ${field('ข้อความเมื่อกลับมาขั้นที่จบแล้ว', 'revisited', j.revisited, 'text', `data-edit="revisited" ${off}`)}
            ${field('ข้อความเมื่อจบ Journey', 'completed', j.completed, 'text', `data-edit="completed" ${off}`)}
            ${textarea('Value labels (key:ชื่อ · หนึ่งรายการต่อบรรทัด)', 'labels', j.labels.map((l) => `${l.key}:${l.label}`).join('\n'), `data-edit="labels" ${off}`)}
            ${field('CSV columns', 'csvColumns', j.csvColumns, 'text', `data-edit="csvColumns" ${off}`)}
            <label class="check"
              ><input
                type="checkbox"
                data-edit="showTotals"
                ${j.showTotals ? 'checked' : ''}
                ${off}
              /><span>แสดงผลรวมให้ผู้เล่นเมื่อจบ · ให้ทีมเนื้อหายืนยันความหมายคะแนนก่อน</span></label
            >
            <p class="field-hint">
              คอลัมน์จำลอง: playerId, journeyId, progress, status, updated · schema จริงยังรอยืนยัน
            </p>
          </div>
        </details>
        <div class="editor-save-bar">
          <div>
            <strong id="editor-save-state" role="status"
              >${state.dirty ? 'ยังไม่ได้บันทึกการแก้ไข' : readOnly ? 'โหมดอ่านอย่างเดียว' : 'พร้อมแก้ไขร่าง'}</strong
            ><span>ข้อมูลจำลอง · ไม่มีการเผยแพร่เข้าเกม</span>
          </div>
          ${!readOnly ? B('บันทึกร่าง', 'save-journey', { kind: 'primary', icon: 'check' }) : ''}
        </div>
      </div>`
    );
  }

  function bind() {
    if (!state.editor || !writable('journeys')) return;
    const j = state.editor;
    const step = j.steps[state.step];
    document.querySelectorAll('[data-edit]').forEach((el) => {
      el.oninput = () => {
        const key = el.dataset.edit;
        j[key] =
          key === 'showTotals'
            ? el.checked
            : key === 'labels'
              ? el.value
                  .split('\n')
                  .filter(Boolean)
                  .map((value) => {
                    const colon = value.indexOf(':');
                    return {
                      key: colon >= 0 ? value.slice(0, colon).trim() : value.trim(),
                      label: colon >= 0 ? value.slice(colon + 1).trim() : value.trim(),
                    };
                  })
              : el.value;
        dirty();
      };
    });
    document.querySelectorAll('[data-step-edit]').forEach((el) => {
      el.oninput = () => {
        step[el.dataset.stepEdit] = el.value;
        dirty();
      };
    });
    document.querySelectorAll('[data-quiz-edit]').forEach((el) => {
      el.oninput = () => {
        step.quiz[el.dataset.quizEdit] = el.value;
        dirty();
      };
      if (el.dataset.quizEdit === 'mode')
        el.onchange = () => {
          el.oninput();
          draw();
          $('[data-quiz-edit=mode]')?.focus({ preventScroll: true });
        };
    });
    document.querySelectorAll('[data-choice]').forEach((el) => {
      el.oninput = () => {
        step.quiz.choices[Number(el.dataset.choice)] = el.value;
        dirty();
      };
    });
    document.querySelectorAll('[data-choice-answer]').forEach((el) => {
      el.onchange = () => {
        step.quiz.answer = Number(el.dataset.choiceAnswer);
        dirty();
      };
    });
    if ($('#has-quiz'))
      $('#has-quiz').onchange = (event) => {
        if (!event.target.checked && step.quiz) {
          event.target.checked = true;
          U.confirm(
            'นำคำถามออกจากขั้นตอนนี้?',
            'คำถามและตัวเลือกจะถูกนำออกจากร่างเมื่อยืนยัน',
            async () => {
              step.quiz = null;
              dirty();
              draw();
              $('#has-quiz')?.focus({ preventScroll: true });
            },
            { danger: true, label: 'นำคำถามออก' },
          );
          return;
        }
        step.quiz = { title: '', mode: 'survey', choices: ['', ''], answer: 0 };
        dirty();
        draw();
        $('[data-quiz-edit=title]')?.focus({ preventScroll: true });
      };
  }

  function action(name, button) {
    if (!['add-choice', 'remove-choice'].includes(name)) return false;
    if (!state.editor || !writable('journeys')) return true;
    const quiz = state.editor.steps[state.step]?.quiz;
    if (!quiz) return true;
    if (name === 'add-choice' && quiz.choices.length < 8) {
      quiz.choices.push('');
      dirty();
      draw();
      $(`[data-choice="${quiz.choices.length - 1}"]`)?.focus({ preventScroll: true });
    }
    if (name === 'remove-choice' && quiz.choices.length > 2) {
      const index = Number(button.dataset.index);
      if (!Number.isInteger(index) || index < 0 || index >= quiz.choices.length) return true;
      quiz.choices.splice(index, 1);
      if (quiz.answer > index) quiz.answer--;
      else if (quiz.answer === index) quiz.answer = -1;
      dirty();
      draw();
      $(`[data-choice="${Math.min(index, quiz.choices.length - 1)}"]`)?.focus({
        preventScroll: true,
      });
    }
    return true;
  }
  return { render, bind, action, focusSection };
};
